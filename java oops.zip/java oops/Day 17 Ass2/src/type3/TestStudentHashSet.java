package type3;
import java.util.HashSet;
import java.util.TreeSet;

import static java.time.LocalDate.parse;

public class TestStudentHashSet {

	public static void main(String[] args) {
		//create empty HS
		HashSet<Student> students=new HashSet<>();
		students.add(new Student(17, "JAVA", "Anupam", 80, parse("2000-01-20"))); 
		students.add(new Student(49, ".NET", "Umesh", 80, parse("2011-11-25")));
		students.add(new Student(33, "C++", "Anup", 80, parse("2010-10-15")));
		students.add(new Student(18, "Spring", "Ashutosh", 80, parse("1995-02-11")));
		students.add(new Student(65, "C", "Babita", 80, parse("1990-08-28")));
		students.add(new Student(105, "C1", "Babita", 80, parse("1990-08-28")));
				
		System.out.println("Size "+students.size());
		//attach for each to display
		for (Student student : students) {
			System.out.println(student);
//			System.out.println("HashCode : "+student.hashCode());
		}
		//Display student detials sorted as per asc order of student id
		System.out.println("Sorted Details");
		TreeSet<Student> ts=new TreeSet<>(students);
		for (Student student : ts) {
			System.out.println(student);
		}
	}

}
