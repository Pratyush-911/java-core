package type1;
import java.util.HashSet;
import static java.time.LocalDate.parse;

public class TestStudentHashSet {

	public static void main(String[] args) {
		//create empty HS
		HashSet<Student> students=new HashSet<>();
		students.add(new Student(17, "JAVA", "umesh", 80, parse("2000-01-20"))); //s1.hashcode() called
		//s2.hashcode() -->get bucketId(modulo = 101%16)---non empty: equals() called and returns false and add the reference
		students.add(new Student(33, "C++", "Anup", 80, parse("2010-10-15")));
		//s3.hashcode() --> equals() called 2 times 
		students.add(new Student(49, ".NET", "Anupam", 80, parse("2011-11-25")));
		//s4.hashcode() --> equals() called 3 times 
		students.add(new Student(65, "C", "Vinay", 80, parse("1990-08-28")));
		//s5.hashcode() --> equals() called 1 time and duplicates get removed
		students.add(new Student(17, "Spring", "Ashutosh", 80, parse("1995-02-11")));
		
		System.out.println("Size "+students.size());
		//attach for each to display
		for (Student student : students) {
			System.out.println(student);
//			System.out.println("HashCode : "+student.hashCode());
		}
	}

}
