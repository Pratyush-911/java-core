package type1;

import java.time.LocalDate;

public class Student {
	private int studentId;
	private String courseName, name;
	private int marks;
	private LocalDate birthDate;

	public Student(int studentId, String courseName, String name, int marks, LocalDate birthDate) {
		super();
		this.studentId = studentId;
		this.courseName = courseName;
		this.name = name;
		this.marks = marks;
		this.birthDate = birthDate;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", courseName=" + courseName + ", name=" + name + ", marks=" + marks
				+ ", birthDate=" + birthDate + "]";
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("In Equals Method");
		if (obj instanceof Student) {
			Student s = (Student) obj;
			return studentId == s.studentId;
		}
		return false;
	}

	@Override
	public int hashCode() {
		System.out.println("\nIn HashCode");
		return studentId;
	}
	

}
