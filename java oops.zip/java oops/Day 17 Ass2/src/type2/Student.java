package type2;
import java.time.LocalDate;

public class Student {
	private int studentId;
	private String courseName,name;
	private int marks;
	private LocalDate birthDate;
	public Student(int studentId, String courseName, String name, int marks, LocalDate birthDate) {
		super();
		this.studentId = studentId;
		this.courseName = courseName;
		this.name = name;
		this.marks = marks;
		this.birthDate = birthDate;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", courseName=" + courseName + ", name=" + name + ", marks=" + marks
				+ ", birthDate=" + birthDate + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((birthDate == null) ? 0 : birthDate.hashCode());
		result = prime * result + ((courseName == null) ? 0 : courseName.hashCode());
		result = prime * result + studentId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Student))
			return false;
		Student other = (Student) obj;
		if (birthDate == null) {
			if (other.birthDate != null)
				return false;
		} else if (!birthDate.equals(other.birthDate))
			return false;
		if (courseName == null) {
			if (other.courseName != null)
				return false;
		} else if (!courseName.equals(other.courseName))
			return false;
		if (studentId != other.studentId)
			return false;
		return true;
	}
	
	
	
//	//override equals method as per studentId & courseName & dob
//	@Override
//	public boolean equals(Object obj) {
//		System.out.println("In Equals Method");
//		if(obj instanceof Student)
//			{
//				Student s=(Student) obj;
//				return studentId==s.studentId && courseName.equals(s.courseName) && birthDate.equals(s.birthDate);
//			}
//			return false;
//	}
//	@Override
//	public int hashCode() {
//		System.out.println("\nIn HashCode");
//		return studentId+courseName.hashCode()+birthDate.hashCode();
//	}
	

}
