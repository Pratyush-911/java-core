//tester class for UI
package com.app.tester;

import com.app.geometry.*;
import java.util.*;

//class defination
class TestPoint {

	public static void main(String[] args) {
		// create scanner class instance to wrap std input stream
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st coordinate x n y");
		// create instance of a point class
		// int x=sc.nextInt();
		// int y=sc.nextInt();
		Point2D p1 = new Point2D(sc.nextInt(), sc.nextInt());
		System.out.println("Enter 2nd coordinate x n y");
		Point2D p2 = new Point2D(sc.nextInt(), sc.nextInt());

		// display details
		System.out.println(p1.getDetails());
		System.out.println(p2.getDetails());
		System.out.println(p1.calcDistance(p1, p2));
		System.out.println(p1.isEqual(p2));
		sc.close();

	}

}
