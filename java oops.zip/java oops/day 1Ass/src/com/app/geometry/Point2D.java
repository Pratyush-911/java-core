 //user definded package made for functional separation
package com.app.geometry;

//class representing a point in x-y cord system
public class Point2D {
	// state: xand y : tight encapsulation
	private int x, y;

	// parametrised const : to init x and y
	public Point2D(int x, int y) {
		this.x = x;
		this.y = y;
	}

	
	// add a bussiness method to return string form of a point(x,y)
	public String getDetails() {
		return "Coordinates :" + x + "," + y;
	}

	// calculateDistance method to calculate distance between two points

	// add a method to check equality of 2 pts: rets true iff:x cood
	public boolean isEqual(Point2D anotherPoint) {
		return (this.x == anotherPoint.x) && (this.y == anotherPoint.y);
	}

	public double calcDistance(Point2D p1, Point2D p2) {
		// TODO Auto-generated method stub

		return Math.sqrt(Math.pow((p2.x - p1.x), 2) + Math.pow((p2.y - p1.y), 2));

	}

}
