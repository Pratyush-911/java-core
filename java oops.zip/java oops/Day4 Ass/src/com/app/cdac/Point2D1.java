package com.app.cdac;



//class representing point in x-y co ord system
public class Point2D1{
	//state : x,y
	private int x,y;
	//parameterized constructor : to inits x and y
	public Point2D1(int x, int y){
		this.x = x;
		this.y = y;
	}

	// add a business logic method to get string from a point(x,y)
	public String getDetails(){
		return "Point ("+x+","+y+")";
	}

	//add a method to check equality of 2 points : returns true iff : x co ord and y co ord of 2 points is same

	boolean isEqual(Point2D1 anotherPoint){
		
		return (this.x == anotherPoint.x)&&(this.y==anotherPoint.y);
	}

	public Point2D createNewPoint(int xoffset,int yoffset){
		Point2D temp = new Point2D(this.x+xoffset,this.y+yoffset);
		return temp;
	}

	public double findDist(Point2D1 anotherObj){
		return (Math.sqrt(Math.pow(this.x-anotherObj.x,2)+Math.pow(this.y-anotherObj.y,2)));
	}

}