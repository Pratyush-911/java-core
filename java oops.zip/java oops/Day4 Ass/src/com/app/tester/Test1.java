package com.app.tester;
import java.util.Scanner;
import com.app.cdac.*;

public class Test1 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter how many points to plot :");
	Point2D1 [] points = new Point2D1[sc.nextInt()];
	
	boolean flag = false;
	int noOfPointsPlotted = 1;
	while(!flag) {
		
		System.out.println("Menu : \n1)Enter Points\n2)Display all points\n3)Calculate Distance b/w 2 points\n4)Exit");
		switch(sc.nextInt()) {
		case 1:
			if(noOfPointsPlotted<=points.length) {
				System.out.println("Enter the index value, x and y coords");
				int ind = sc.nextInt();
				if(ind<=points.length && ind>0 && points[ind-1]==null) {
					points[ind-1]=new Point2D1(sc.nextInt(),sc.nextInt());
					noOfPointsPlotted++;
					
				}
				else if(points[ind-1]!=null) {
					System.out.println("This index is alreday taken.Please try again.");
				}
				else {
					System.out.println("Please enter the index value within the range");
				}
			}
			else {
				System.out.println("Limit reached");
			}
			break;
		
		case 2:
			for(Point2D1 point:points) {
				if(point!= null) {
					System.out.println(point.getDetails());
				}
			}
			break;
		case 3:
			System.out.println("Enter the indexes of points to calculate distance :");
			int i1 = sc.nextInt();
			int i2 = sc.nextInt();
			
			if(points[i1-1]!=null && points[i2-1]!=null && i1<=points.length && i1>0 && i2<=points.length && i2>0) {
				System.out.println(points[i1-1].findDist(points[i2-1]));
			}
			else if(points[i1-1]==null) {
				System.out.println("There is no point at "+i1+" index.");
			}
			else if(points[i2-1]==null) {
				System.out.println("There is no point at "+i2+" index.");
			}
			else
				System.out.println("Please enter valid index");
			break;
		case 4:
			flag = true;
			System.out.println("------------------Thank You-----------------");
			break;
		}	
	}
	}
}



