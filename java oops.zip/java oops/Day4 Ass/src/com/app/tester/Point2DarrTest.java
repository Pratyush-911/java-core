package com.app.tester;
import java.util.Scanner;
import com.app.cdac.Point2D;
public class Point2DarrTest {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Point2D[] point=new Point2D[2];
		for(int i=0;i<point.length;i++) {
			System.out.println("enter the point to calculate distance:");
			point[i]=new Point2D(sc.nextInt(),sc.nextInt());
		}
		
		for(Point2D point1:point) {
			System.out.println(point1.getDetails());
		
		}
		System.out.println(point[0].calcDistance(point[0],point[1]));
		
sc.close();
	}

}
