package com.app.tester;
import java.util.Arrays;
import java.util.Scanner;

import com.app.cdac.Box;
public class BoxTestArray {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of boxe you want");
        Box[] boxes=new Box[sc.nextInt()];
        for(int i=0;i<boxes.length;i++) {
        	System.out.println("enter the box dim");
        	boxes[i]=new Box(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
        }
        for(Box b:boxes) {
        	
        	System.out.println(b.getBoxDetails());
        	System.out.println(b.computeVolume());       	
        }
        System.out.println(Arrays.toString(boxes));
        sc.close();
	}

}
