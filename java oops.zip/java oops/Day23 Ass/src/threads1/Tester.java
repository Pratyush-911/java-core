package threads1;
import static  java.lang.Thread.currentThread;
public class Tester {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());//1 thread(w/o counting gc)
//create child thread n observe the concurrency
		NewThread t1=new NewThread("one");
		NewThread t2=new NewThread("two");
		NewThread t3=new NewThread("three");
		NewThread t4=new NewThread("four");//1+4:runnable thread 
		//NewThread t1=new NewThread("");
		//main:dummy logic 
		for(int i=0;i<10;i++) {
			System.out.println(currentThread().getName()+"exec#"+i);
			Thread.sleep(1000);//msec:state:blocked on sleep

	}
		System.out.println(currentThread().getName()+"over");

}
}