package threads3;
import static  java.lang.Thread.currentThread;
public class Tester {

	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread());//1 thread(w/o counting gc)
//create child thread n observe the concurrency
		//create runnable task instance
		RunnableTask task=new RunnableTask();//runnable thrd:1
		//threded class constr:impl:thread(Runnbale inst,string name)
		Thread t1=new Thread(task,"one");
		Thread t2=new Thread(task,"two");
		Thread t3=new Thread(task,"three");
		Thread t4=new Thread(task,"four");//runnable thread :1
		t1.start();t2.start();t3.start();t4.start();//runnable thread:5
		//main:dummy logic 
		for(int i=0;i<10;i++) {
			System.out.println(currentThread().getName()+"exec#"+i);
			Thread.sleep(500);//msec:state:blocked on sleep

	}
		System.out.println("main waiting for child thrd to complete exec");
		System.out.println("thread status"+t1.isAlive()+""+t4.isAlive());
		System.out.println(currentThread().getName()+"main over");
t1.join();
t2.join();
t3.join();
t4.join();
System.out.println("child thread is over");
System.out.println("child thread is over"+t1.isAlive()+""+t4.isAlive());
System.out.println("main over");

}
}