package threads3;
import static java.lang.Thread.currentThread;
import static java.lang.Thread.currentThread;

public class RunnableTask implements Runnable{
	//Runnable task is not a thread
	//Runnable task is a runnable:yes
//add a parameterised constructor to set name of thread
@Override
	
	public void run()
	{
		System.out.println(currentThread().getName()+"started");
		try {
			//b.l:simply(dummy):loop
			for(int i=0;i<10;i++) {
				System.out.println(currentThread().getName()+"exec#"+i);
				Thread.sleep(1000);//msec:state:blocked on sleep
			}
			System.out.println("end of try");
		}catch(Exception e) {
			System.out.println("error in"+currentThread().getName()+"exc"+e);
		}
		
		System.out.println(currentThread().getName()+"over");
	}
	
}
