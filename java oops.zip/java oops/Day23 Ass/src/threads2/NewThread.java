package threads2;
import static java.lang.Thread.currentThread;

public class NewThread extends Thread{
//add a parameterised constructor to set name of thread
	public NewThread(String name) {
		super(name);
		//exec has not yet started!
		start();//state:runnable(ready pool or running)
		System.out.println("in constr by"+currentThread().getName());//main
		//run();
	}
	
	@Override
	
	public void run()
	{
		System.out.println(currentThread().getName()+"started");
		try {
			//b.l:simply(dummy):loop
			for(int i=0;i<10;i++) {
				System.out.println(currentThread().getName()+"exec#"+i);
				Thread.sleep(1000);//msec:state:blocked on sleep
			}
			System.out.println("end of try");
		}catch(Exception e) {
			System.out.println("error in"+currentThread().getName()+"exc"+e);
		}
		
		System.out.println(currentThread().getName()+"over");
	}
	
}
