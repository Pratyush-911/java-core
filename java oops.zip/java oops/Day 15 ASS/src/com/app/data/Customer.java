package com.app.data;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Customer
{
	private String email , name , password;
	private int registrationAmount ;
	private Date dob;
	private String type;
	
	public static SimpleDateFormat sdf;
	static {
		sdf=new SimpleDateFormat("yyyy-MM-dd");
	}
	
	public Customer(String name , String email  ,int registrationAmount,String password, Date dob, String type)
	{
		this.email=email;
		this.name=name;
		this.registrationAmount=registrationAmount;
		this.password=password;
		this.dob = dob;
		this.type= type.toUpperCase();
	}
	public Customer(String email)
	{
		this.email=email;
	}
	
	@Override
	public String toString()
	{
		return "Customer name : "+name+" email: "+email+ " Registration amount : "+registrationAmount + " Date of Birth : " + sdf.format(dob) + " Customer type : "+this.type;
	}
	
	@Override
	public boolean equals(Object cust)
	{
		return cust instanceof Customer ?this.email.equals(((Customer)cust).email) : false ;
	}
	
	public Date getDob()
	{
		return this.dob;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
}
