package com.app.data;

import java.util.*;

import custom_exceptions.MyException;

import static utils.ValidationRules.*;

public class CustomerRegistration {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
//			Customer[] customer = new Customer[10];
			ArrayList<Customer> customer = new ArrayList<Customer>();
//			int count = 0;
			boolean exit = false;
			while (!exit) {
				System.out.println(
						"Options\n1)Register Customer \n2)Fetch customer details \n3)Customer Login \n4)Unsubscribe Customer \n5)Display All Customer Details\n6)Exit");
				System.out.println("Enter your choice");
				try {
					switch (sc.nextInt()) {
					case 1:
						System.out.println("Enter Customer's email");
						String emailCust = sc.next();
						checkEmail(emailCust);
						System.out.println("Enter Date Of Birth");
						Date dob = Customer.sdf.parse(sc.next());
						duplicateCustomer(customer, emailCust, dob);
						checkDob(dob);
						System.out.println("Enter Customer Type");
						String type = sc.next();
						checkCustomerType(type);
						System.out.println("Enter Customer's name");
						String nameCust = sc.next();
						System.out.println("Enter password ");
						String passwordCust = sc.next();
						passCheck(passwordCust);
						System.out.println("Enter registration amount");
						int registrationAmountCust = sc.nextInt();
						RegAmountCheck(registrationAmountCust);
//						System.out.println("Enter country");
//						String country = sc.next();
//						checkCountry(country);
//						System.out.println("Enter city, state, phoneNo");
						customer.add(
								new Customer(nameCust, emailCust, registrationAmountCust, passwordCust, dob, type));
						System.out.println("Customer Registered successfully");
//						customer[count].setAddress(sc.next(), sc.next(), country, sc.next());
//						count++;
						break;
					case 2:
						try {
							System.out.println("Enter email and dob");
							String email = sc.next();
							Date dob2 = Customer.sdf.parse(sc.next());
							fetchDetails(customer, email, dob2);
						} catch (MyException e) {
							e.printStackTrace();
						}
						break;
					case 3:
						System.out.println("Enter email, Date of Birth and password");
						try {
							loginCustomer(customer, sc.next(), Customer.sdf.parse(sc.next()),
									sc.next());
						} catch (MyException e) {
							e.printStackTrace();
						}
						break;
					case 4:
						try {
							System.out.println("Enter email and dob");
							String email = sc.next();
							Date dob3 = Customer.sdf.parse(sc.next());
							Customer c1 = fetchDetails(customer, email, dob3);
							customer.remove(c1);
							System.out.println("Customer unsubscribed successfully");
						} catch (MyException e) {
							e.printStackTrace();
						}
						break;
					case 5:
						for (Customer cust : customer) {
							System.out.println(cust.toString());
						}
						break;
					case 6:
						exit = true;
						break;
					default: System.out.println("Invalid option selected");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	

}
