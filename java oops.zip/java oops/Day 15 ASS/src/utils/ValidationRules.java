package utils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

import com.app.data.Customer;
import com.app.data.CustomerType;

import custom_exceptions.MyException;

public class ValidationRules {
	public static void checkEmail(String email) throws MyException {
		if (email.length() < 8 || email.length() > 30)
			throw new MyException("Length of email should be greater than 8 and less than 15");

		if (!(email.contains("@")))
			throw new MyException("Email should contain @ symbol.");

		if (!(email.endsWith(".com")))
			throw new MyException("Email should end with .com ");
	}

	public static void passCheck(String password) throws MyException {
		if (!(password.matches("((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{6,20})")))
			throw new MyException("Password must be of length 6-20 char and should contain special chars and digits");
	}

	public static void RegAmountCheck(int registrationAmount) throws MyException {
		if (registrationAmount % 500 != 0)
			throw new MyException("Registration amount should be multiple of 500");
	}

	public static void duplicateCustomer(ArrayList<Customer> customer, String email, Date dob) throws MyException {
		for (Customer c : customer) {
			if (c != null && c.equals(new Customer(email))
					&& Customer.sdf.format(c.getDob()).equals(Customer.sdf.format(dob))) {
				throw new MyException("Duplicate customer found");
			}
		}
	}

	public static void checkDob(Date dob) throws ParseException, MyException {
		Date d = Customer.sdf.parse("2020-01-01");
		if (!dob.before(d))
			throw new MyException("Customer Date of birth must be before 1st Jan 2020");
	}

	public static void checkCustomerType(String s) throws MyException {
		boolean flag = false;
		for (CustomerType c : CustomerType.values()) {
			if (!c.name().equals(s.toUpperCase()))
				flag = false;
			else {
				flag = true;
				break;
			}
		}
		if (!flag)
			throw new MyException("Customer type must be either : SILVER OR GOLD OR PLATINUM");
	}

	public static void checkCountry(String country) throws MyException {
		if (!country.equalsIgnoreCase("India"))
			throw new MyException("Currently we are supporting , customer registration from within India");
	}

	public static void loginCustomer(ArrayList<Customer> customer, String email, Date dob, String password)
			throws MyException {
		boolean flag = false;
		for (Customer c : customer) {
			if (c != null && c.equals(new Customer(email)))
				if (c != null && Customer.sdf.format(c.getDob()).equals(Customer.sdf.format(dob)))
					if (c != null && c.getPassword().equals(password)) {
						flag = true;
						break;
					}
		}
		if (!flag)
			throw new MyException("Customer with given details does not exists");
		else System.out.println("Logged in successfully");
	}
	
	public static Customer fetchDetails(ArrayList<Customer> customer, String email, Date dob2) throws MyException {
		boolean flag=false;
		Customer cust = null;
		for (Customer c : customer) {
			if (c != null && c.equals(new Customer(email))
					&& Customer.sdf.format(c.getDob()).equals(Customer.sdf.format(dob2))) {
				cust=c;
				flag=true;
				break;
			}
		}
		if (!flag) throw new MyException("Customer not found");
		else 
			System.out.println("Customer found");
		return cust;
	}
}
