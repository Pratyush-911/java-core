package custom_exceptions;

@SuppressWarnings("serial")
public class CustomerException extends Exception{

	public CustomerException(String message) {
		super(message);
		
	}

	@Override
	public String getMessage() {
		
		return super.getMessage();
	}

	

}
