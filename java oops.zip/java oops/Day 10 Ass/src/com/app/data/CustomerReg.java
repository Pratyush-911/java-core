package com.app.data;
import java.util.Scanner;

import Tester.Validation;
public class CustomerReg {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int count=0;
	System.out.println("enter the number of customer want to add");
	Customer[] customer=new Customer[sc.nextInt()];
	
		try {
	for(int i=0;i<customer.length;i++) {
		System.out.println("enter the email");
		String email=sc.next();
		//Validation.validCustomer(customer, email);
		System.out.println("enter the passward");
		String passward=sc.next();
		System.out.println("enter the name");
		String name=sc.next();
		System.out.println("enter the city");
		String city=sc.next();
		System.out.println("enter the regamt");
		double regamt=sc.nextDouble();
		customer[count++]=new Customer(email,passward,name,regamt,city);
		
	}
	
	
	}
	catch(Exception e) {
		System.out.println(e.getMessage());
	}
	for(Customer customer2 : customer) {
		System.out.println(customer2.toString());
	}
	sc.close();
}
}

