package com.app.data;

public class Customer {
private String email;
private String passward;
private String name;
private double regamt;
private String city;
public Customer(String email, String passward, String name, double regamt, String city) {
	super();
	this.email = email;
	this.passward = passward;
	this.name = name;
	this.regamt = regamt;
	this.city = city;
}
@Override
public String toString() {
	return "Customer Details [email=" + email + ", passward=" + passward + ", name=" + name + ", regamt=" + regamt + ", city="
			+ city +"]";
}
public boolean equals(Object obj) {
	Customer cust=(Customer)obj;
	if(email.equals(cust.email))
	return false;
	return true;
}

}
