package Tester;
import com.app.data.Customer;

import custom_exceptions.CustomerException;

public class Validation {
		
		public static void validCustomer(Customer[] custData,String email) throws CustomerException
		
		{
			if(!email.matches("@.")) {
				throw new CustomerException("Email Incorrect");
			}
			
		}
	}
		

	


