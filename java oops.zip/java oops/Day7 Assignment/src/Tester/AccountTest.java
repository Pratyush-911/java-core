package Tester;

import com.app.org.*;
import java.util.*;

public class AccountTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean notExit = true;

		while (notExit) {
			System.out.println("Choose option...");
			System.out.println("1. Saving Account\n2. Current Account\n3. Loan Account\n4. Exit");
			int key = sc.nextInt();
			switch (key) {
			case 1:
				System.out.println("How many Saving Account you want to create?");
				SavingAccount[] sarr = new SavingAccount[sc.nextInt()];
				for (int i = 0; i < sarr.length; i++) {
					System.out.println("Enter Customer Name of #" + i);
					String type = "Saving";
					SavingAccount s = new SavingAccount(sc.nextLine() + sc.nextLine(), type);
					System.out.println(s.toString());
					boolean flag = true;
					while (flag) {
						System.out.println("What do you want to do next ?");
						System.out.println(
								"1. Deposit\n2. Withdraw\n3. Calculate Simple Interest\n4. Calcualte Income tax\n5. Exit");
						int option = sc.nextInt();
						switch (option) {
						case 1:
							System.out.println("Enter amount to deposit");
							s.deposit(sc.nextDouble());
							System.out.println(s.toString());
							break;
						case 2:
							System.out.println("Enter amount to withdraw");
							s.withdraw(sc.nextDouble());
							System.out.println(s.toString());
							break;
						case 3:
							System.out.println("Simple Interest : " + s.calculate_simple_interest());
							break;
						case 4:
							System.out.println("Income Tax : " + s.compute_incometax());
							break;
						case 5:
							flag = false;
							break;
						default: System.out.println("Invalid option selected!!! Please select correct option.");
						}
					}

				}
				break;
			case 2:
				System.out.println("How many Cuurent Account you want to create?");
				CurrentAccount[] carr = new CurrentAccount[sc.nextInt()];
				for (int i = 0; i < carr.length; i++) {
					System.out.println("Enter Customer Name of #" + i);
					String type = "Current";
					CurrentAccount c = new CurrentAccount(sc.nextLine() + sc.nextLine(), type);
					System.out.println(c.toString());
					boolean flag = true;
					while (flag) {
						System.out.println("What do you want to do next ?");
						System.out.println(
								"1. Deposit\n2. Withdraw\n3. Calculate Income tax\n4. Exit");
						int option = sc.nextInt();
						switch (option) {
						case 1:
							System.out.println("Enter amount to deposit");
							c.deposit(sc.nextDouble());
							System.out.println(c.toString());
							break;
						case 2:
							System.out.println("Enter amount to withdraw");
							c.withdraw(sc.nextDouble());
							System.out.println(c.toString());
							break;
						case 3:
							System.out.println("Income Tax : " + c.compute_incometax());
							break;
						case 4:
							flag = false;
							break;
						default: System.out.println("Invalid option selected!!! Please select correct option.");
						}
					}

				}
				break;
			case 3:
				System.out.println("How many Loan Account you want to create?");
				LoanAccount[] larr = new LoanAccount[sc.nextInt()];
				for (int i = 0; i < larr.length; i++) {
					System.out.println("Enter Customer Name and number of installments of #" + i);
					String type = "Loan";
					LoanAccount l = new LoanAccount(sc.nextLine() + sc.nextLine(), type, sc.nextInt());
					System.out.println(l.toString());
					boolean flag = true;
					while (flag) {
						System.out.println("What do you want to do next ?");
						System.out.println(
								"1. Deposit\n2. Withdraw\n3. Calcualte Income tax\n4. Display Loan Details\n5. Exit");
						int option = sc.nextInt();
						switch (option) {
						case 1:
							System.out.println("Enter amount to deposit");
							l.deposit(sc.nextDouble());
							System.out.println(l.toString());
							break;
						case 2:
							System.out.println("Enter amount to withdraw");
							l.withdraw(sc.nextDouble());
							System.out.println(l.toString());
							break;
						case 3:
							System.out.println("Income Tax : " + l.compute_incometax());
							break;
						case 4:
							System.out.println("EMI : "+l.display_loan_details());
							break;
						case 5:
							flag = false;
							break;
						default: System.out.println("Invalid option selected!!! Please select correct option.");
						}
					}

				}
				break;
			case 4:
				notExit = false;
				break;
			default: System.out.println("Invalid option selected!!! Please select correct option.");
			}

		}

	}
}