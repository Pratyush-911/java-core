package com.app.org;

public class CurrentAccount extends Account {

	public CurrentAccount(String customer_name, String account_type) {
		super(customer_name, account_type);
	}

	@Override
	public double compute_incometax() {
		return this.balance * 0.01;
	}

}
