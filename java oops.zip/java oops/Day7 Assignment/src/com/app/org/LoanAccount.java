package com.app.org;

public class LoanAccount extends Account {
	int loan_installments;
	double emi;

	public LoanAccount(String customer_name, String account_type, int loan_installments) {
		super(customer_name, account_type);
		this.loan_installments = loan_installments;
	}

	@Override
	public double compute_incometax() {
		return (this.balance * 0.05) - (this.emi * 0.01);
	}
	
	public double display_loan_details() { 
		this.emi = this.balance / this.loan_installments;
		return emi;
	}

}
