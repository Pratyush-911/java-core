package com.app.org;

public abstract class Account {
	static int account_no = 0;
	String customer_name;
	String account_type;
	double balance = 0;

	public Account(String customer_name, String account_type) {
		super();
		this.customer_name = customer_name;
		Account.account_no++;
		this.account_type = account_type;
	}

	public String toString() {
		return account_no + " " + customer_name + " " + account_type + " " + balance;
	}

	public abstract double compute_incometax();

	public void withdraw(double amt) {
		this.balance -= amt;
	};

	public void deposit(double amt) {
		this.balance += amt;
	};

}
