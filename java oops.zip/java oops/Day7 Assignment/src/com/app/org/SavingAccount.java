package com.app.org;

public class SavingAccount extends Account {
	double si;

	public SavingAccount(String customer_name, String account_type) {
		super(customer_name, account_type);
	}

	@Override
	public double compute_incometax() {
		return this.balance * 0.1;
	}
	
	public double calculate_simple_interest() { 
		this.si = (balance * 5 * 1) / 100;
		return this.si;
	}

}
