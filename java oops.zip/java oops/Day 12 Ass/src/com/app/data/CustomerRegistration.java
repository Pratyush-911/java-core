package com.app.data;

import java.util.*;

import custom_exceptions.MyException;

import static utils.ValidationRules.*;

public class CustomerRegistration {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			Customer[] customer = new Customer[10];
			int count = 0;
			boolean exit = false;
			while (!exit) {
				System.out.println(
						"Options\n1)Register Customer \n2)Find Customer in particular city \n3)Change phone number \n4)Display details of all Customers \n5)Exit");
				System.out.println("Enter your choice");
				try {
					switch (sc.nextInt()) {
					case 1:
						System.out.println("Enter Customer's email");
						String emailCust = sc.next();
						checkEmail(emailCust);
						System.out.println("Enter Date Of Birth");
						Date dob = Customer.sdf.parse(sc.next());
						duplicateCustomer(customer, emailCust, dob);
						checkDob(dob);
						System.out.println("Enter Customer Type");
						String type = sc.next();
						checkCustomerType(type);
						System.out.println("Enter Customer's name");
						String nameCust = sc.next();
						System.out.println("Enter password ");
						String passwordCust = sc.next();
						passCheck(passwordCust);
						System.out.println("Enter registration amount");
						int registrationAmountCust = sc.nextInt();
						RegAmountCheck(registrationAmountCust);
						System.out.println("Enter country");
						String country = sc.next();
						checkCountry(country);
						System.out.println("Enter city, state, phoneNo");
						customer[count] = new Customer(nameCust, emailCust, registrationAmountCust, passwordCust, dob,
								type);
						customer[count].setAddress(sc.next(), sc.next(), country, sc.next());
						count++;
						break;
					case 2:
						System.out.println("Enter the city to be searched for");
						String citySearch = sc.next();
						for (Customer c : customer) {
							if (c != null) {
								if (c.getCity().equals(citySearch))
									System.out.println(c);
								else
									System.out.println("City not found!!");
							}
						}
						break;
					case 3:
						System.out.println("Enter email, Date of Birth and password");
						try {
							Customer c1 = checkCustomerExists(customer, sc.next(), Customer.sdf.parse(sc.next()), sc.next());
							System.out.println("Enter new phone no");
							c1.setPhoneNo(sc.next());
							System.out.println("Phone number updated");
						} catch (MyException e) {
							e.printStackTrace();
						}
						break;
					case 4:
						for (Customer c : customer) {
							if (c != null)
								System.out.println(c);
						}
						break;
					case 5:
						exit = true;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	
}
