package Tester;
import java.util.Scanner;
import com.app.fruits.*;
import com.app.fruits.Fruit;

import Utils.FruitUtils;

public class Basket {
	public static int count = 0;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter basket size.");
		Fruit[] fruitBasket = new Fruit[sc.nextInt()];
		showOptions(fruitBasket);
     	sc.close();
	}

	public static void showOptions(Fruit[] fruitDetais) {
		System.out.println("Select an option :" + "\n1.Add Apple \n2.Add Orange \n3. Add Cherry \n4.Show Basket" + "\n5.Exit");
		Scanner sc = new Scanner(System.in);
		int option = sc.nextInt();
		if (option == 5) {
			System.out.println("Application stopped successfully.");
			sc.close();
			System.exit(0);
		} else {
			addFruitToBasket(option, fruitDetais);
			showOptions(fruitDetais);
		}
	}

	public static void addFruitToBasket(int option, Fruit[] addFruit) {
		switch (option) {
		case 1:
			System.out.println("Add Apple");
			Scanner sc = new Scanner(System.in);
			String name = sc.next();
			Apple apple = new Apple(name);
			apple.setName(name);
			Fruit f1 = apple;
			FruitUtils.addFruit(f1, addFruit, count);
			count++;
			System.out.println("Apple Details Added Successfully");
			break;
		case 2:
			System.out.println("Add Orange");
			Scanner scan = new Scanner(System.in);
			String name1 = scan.next();
			Orange orange = new Orange(name1);
			orange.setName(name1);
			Fruit f2 = orange;
			FruitUtils.addFruit(f2, addFruit, count);
			count++;
			System.out.println("Apple Details Added Successfully");
			break;
		case 3:
			System.out.println("Add cherry");
			Scanner scanner = new Scanner(System.in);
			String name2 = scanner.next();
			Cherry cherry = new Cherry(name2);
			cherry.setName(name2);
			Fruit f3 = cherry;
			FruitUtils.addFruit(f3, addFruit, count);
			count++;
			System.out.println("Apple Details Added Successfully");
			break;

		case 4:
			System.out.println("Fruit Details");
			boolean showMsg=true;
				for (Fruit fruit : addFruit) {
					if(null != fruit) {
						System.out.println("Fruit Added in Basket is : "+fruit.fruitName());
						fruit.displayTaste();
						showMsg=false;
					}
				}
				if(showMsg) {
					System.out.println("No fruit in basket.");
				}
				
		}
		
	}
}