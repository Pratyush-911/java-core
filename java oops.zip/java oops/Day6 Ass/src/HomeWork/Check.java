package HomeWork;
import HomeWork.EasyOver;
public class Check {

	public static void main(String[] args) {
		EasyOver easy=new EasyOver();
			easy.go(x);
	
	}

}
