package Utils;
import com.app.fruits.Fruit;
public class FruitUtils{
	public static void addFruit(Fruit f,Fruit[] basket1,int counter) {
		basket1[counter]=f;
	}
}

