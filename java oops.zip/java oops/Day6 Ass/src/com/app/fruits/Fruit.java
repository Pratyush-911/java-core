package com.app.fruits;

public class Fruit {
private String name;
public Fruit(String name) {
	super();
	this.name=name;
}
public String taste() {
	return "no specific taste";
}
public String fruitName() {
	return name;
}

public void displayTaste() {
	System.out.println("");
}
}
