package com.app.fruits;

public class Orange extends Fruit {
	public Orange(String name) {
		super(name);	
	}
	public String taste() {
		return "sour";
		}
		public void displayTaste() {
			System.out.println(super.fruitName()+" is "+taste()+" in taste ");
			
		}
		public void setName(String name) {
			
			
		}
}
