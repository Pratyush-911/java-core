package com.app.fruits;
//import com.app.fruits.Fruit;
public class Apple extends Fruit {

	public Apple(String name) {
		super(name);
		
	}
public String taste() {
return "sweet";
}
public void displayTaste() {
	System.out.println(super.fruitName()+" is "+taste()+" in taste ");
	
}
public void setName(String name) {
	
}
}