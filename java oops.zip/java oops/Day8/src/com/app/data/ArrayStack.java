package com.app.data;

public class ArrayStack implements Stack {
public int [] item;
public int stackTop;
public ArrayStack(int[] item, int stackTop) {
	
	this.item = item;
	this.stackTop = stackTop;
	
}

public void push(int x) {
	item[stackTop]=x;
	stackTop++;
}
public int pop () {
	int returnItem;
	returnItem = item[stackTop-1]; 
	 stackTop--;
	return returnItem;
}

}
