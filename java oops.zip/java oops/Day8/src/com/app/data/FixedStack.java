package com.app.data;

public class FixedStack implements Stack {

//	private int stk[ ];
	private Employee stk[];
	private int top;

	public FixedStack() {
//            stk=new int[STACK_SIZE];
		stk = new Employee[STACK_SIZE];
		top = -1;
	}

//	@Override
//	public void push(int item) {
//		 if(tos==stk.length-1)
//         {
//                 System.out.println("Stack Overflows");
//                
//         }
//         else
//                 stk[++tos]=item;
//		
//	}

	@Override
	public void push(Employee item) {
		if (top == stk.length - 1) 
			System.out.println("Stack Overflows");
		 else {
			stk[++top] = item;
			System.out.println("Data pushed : " + item.toString());
		}
	}

//	@Override
//	public int pop() {
//		 if(top<0)
//         {
//                 System.out.println("Stack Underflows");
//                 return 0;
//         }
//         else
//                 return stk[top--];
//		
//	}

	@Override
	public Employee pop() {
		if (top < 0) {
			System.out.println("Stack Underflows");
			return null;
		} else
			return stk[top--];
	}

}
