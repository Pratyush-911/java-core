package com.app.data;

public class GrowableStack implements Stack {
	private Employee stk[];
	private int tos;

	public GrowableStack() {
		stk = new Employee[STACK_SIZE];
		tos = -1;
	}

//	@Override
//	public void push(int item) {
//		 if(tos==stk.length-1)
//         {
//                 System.out.println("Stack Overflows.");
//                 int temp[]=new int[stk.length * 2];
//                 for(int i=0;i<stk.length;i++)
//                         temp[i]=stk[i];
//                 stk=temp;
//                 stk[++tos]=item;
//         }
//         else
//                 stk[++tos]=item;
//	}
//
//	@Override
//	public int pop() {
//		  if(tos<0)
//          {
//                  System.out.println("Stack Underflows.");
//                  return 0;
//          }
//          else
//                  return stk[tos--];
//	}

	@Override
	public void push(Employee item) {
		if (tos == stk.length - 1) {
			System.out.println("Stack Overflows.");
			Employee temp[] = new Employee[stk.length * 2];
			for (int i = 0; i < stk.length; i++)
				temp[i] = stk[i];
			stk = temp;
			stk[++tos] = item;
			System.out.println("Data pushed : " + item.toString());

		} else {
			stk[++tos] = item;
			System.out.println("Data pushed : " + item.toString());
		}
	}

	@Override
	public Employee pop() {
		if (tos < 0) {
			System.out.println("Stack Underflows.");
			return null;
		} else
			return stk[tos--];
	}

}