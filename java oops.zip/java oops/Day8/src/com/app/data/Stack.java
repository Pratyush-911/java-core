package com.app.data;

public interface Stack {
//	public void push(int item);
//	public int pop();
	public void push(Employee item);
	public Employee pop();
	public static final int STACK_SIZE = 2;
}

