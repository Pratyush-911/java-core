package com.app.data;

public class Employee {
	public int id;
	public String name;
	public double salary;

	public Employee(int id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public String toString() {
		return this.id + " " + this.name + " " + this.salary;
	}
}
