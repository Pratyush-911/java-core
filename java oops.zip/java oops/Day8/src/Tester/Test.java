package Tester;

import java.util.Arrays;
import java.util.Scanner;

import com.app.data.Employee;
import com.app.data.FixedStack;
import com.app.data.GrowableStack;
import com.app.data.Stack;

public class Test {

	@SuppressWarnings("unused")
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Stack ref = null;
		boolean flag = true;
		System.out.println("Choose any one option...");
		

		while (flag) {
			System.out.println("1. Fixed Stack\n2. Growable Stack\n3. Push data\n4. Pop data and display\n5. Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				if (ref == null) {
					ref = new FixedStack();
					System.out.println("Fixed Stack chosen");
				}
				else
					System.out.println("Stack already chosen!");
				break;
			case 2:
				if (ref == null) {
					ref = new GrowableStack();
					System.out.println("Growable Stack chosen");
				}
				else
					System.out.println("Stack already chosen!");
				break;
			case 3:
				if (ref == null) 
					System.out.println("Stack not chosen!");
				 else {
					System.out.println("Enter employee id, name and salary");
					Employee e = new Employee(sc.nextInt(), sc.nextLine() + sc.next(), sc.nextDouble());
					ref.push(e);
				}
				break;
			case 4:
				if (ref == null) 
					System.out.println("Stack not chosen!");
				 else {
					Employee e = ref.pop();
					System.out.println("Data popped : "+e.toString());
				}
				break;
			case 5:
				flag = false;
				break;
			default:
				System.out.println("Invalid option selected !!!");
			}

		}

	}
}
