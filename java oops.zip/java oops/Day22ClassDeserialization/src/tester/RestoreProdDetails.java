package tester;

import java.util.Scanner;
import static utils.IOUtils.restoreProduct;

public class RestoreProdDetails {

	public static void main(String[] args) {
		try (Scanner sc=new Scanner(System.in)){
			System.out.println("Enter file Name, to restore product details");
			System.out.println(restoreProduct(sc.nextLine()));
			System.out.println("Restored data...");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
