package tester;

import java.util.Map;
import java.util.Scanner;

import com.app.core.Product;

import static utils.IOUtils.restoreProduct;

public class RestoreProdDetails2 {

	public static void main(String[] args) {
		try (Scanner sc=new Scanner(System.in)){
			System.out.println("Enter file Name, to restore product details");
			//objective : display the names and price of all the products: on separate lines.
			Map<Integer, Product> map=restoreProduct(sc.nextLine());
			map.values().forEach(System.out::println);
			System.out.println();
			map.forEach((k,v)->System.out.println(v.getName()+" @ "+v.getPrice()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
