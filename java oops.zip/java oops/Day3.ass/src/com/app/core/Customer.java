package com.app.core;
public class Customer {
	private String name, email;
	private int age;
	private double creditLimit;

	// parameterized constructor to accept all details from user
	public Customer(String name, String email, int age, double creditLimit) {
		this.name = name;
		this.email = email;
		this.age = age;
		this.creditLimit = creditLimit;
	}

	/*
	 * argument less constructor to init default name to "Riya" , email to
	 * "riya@gmail.com",age=25,creditLimit=10000
	 */
	public Customer() {
		this.name = "Riya";
		this.email = "riya@gmail.com";
		this.age = 25;
		this.creditLimit = 10000.00;
	}
	public Customer(String name,String email,int age) {
		this.name = name;
		this.email = email;
		this.age = age;
		this.creditLimit = 10000.00;
	}

				
	public void dispDetail() {
		System.out.println(this.name+" "+this.creditLimit);
	}
	public String dispDetails() {
		return "Name : "+this.name + "\nemail:"+this.email+"\nAge:"+this.age +"\nCreditLimkit :"+this.creditLimit + "\n";
	}


	public double getCreditLimit() {
		return creditLimit;
	}


	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	


		
}