package com.app.core;

public class Student {
	private int id;
	private String name;
	private String email;
	private int age;
	private double gpa;
//Accept id,name,email,age
	public Student(int id, String name, String email, int age) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.age = age;
	}

	public Student() {

	}
	
		//fetch details
	public String fetchDetails() {
		return "ID : " + id + "\nName : " + name + "\nEmail : " + email + "\nAge : " + age + "\nGPA = "+gpa+"\n";
	}
	
	//Accept 3 method Argument && normalize it to 10 scale
	public double computeGPA(double scQuiz, double scTest, double scAssign) {
		gpa = (scQuiz * 0.20 + scTest * 0.50 + scAssign * 0.30)/10;
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public String getName() {
		return name;
	}

}
