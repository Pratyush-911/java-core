package com.app.tester;
import java.util.Scanner;
import com.app.core.Customer;
public class TestCustomer {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter customer1 details:Name,Email,Age,Credit Limit");
		Customer user1=new Customer(sc.nextLine(),sc.next(),sc.nextInt(),sc.nextDouble());
		Customer user2=new Customer();
		System.out.println("enter customer3 details:Name,Email,Age");
		sc.nextLine();
		Customer user3=new Customer(sc.nextLine(),sc.next(),sc.nextInt());
		System.out.println("Customert details");
		System.out.println(user1.dispDetails());
		System.out.println(user2.dispDetails());
		System.out.println(user3.dispDetails());
		System.out.println("enter the updated creditLimit");
		user3.setCreditLimit(sc.nextDouble());
		System.out.println("updated creditLimit is:"+user3.getCreditLimit());
		System.out.println(user3.dispDetails());
		/*Customer ds = new Customer();
		ds.dispDetail();
		System.out.println("enter user name");
		String name=sc.nextLine();
		System.out.println("enter user email");
		String email=sc.nextLine();
		System.out.println("enter user age");
		int age=sc.nextInt();
		Customer user=new Customer(name,email,age);
		user.dispDetail();
		*/
		
		sc.close();
	}

}
