
	
		
	package com.app.tester;

	import java.util.Scanner;
	import com.app.core.*;

	public class TestStudent {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			//enter the student1 details
			System.out.println("Enter Student 1st Details : ID, Name, Email and Age.");
			Student detailS1 = new Student(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.next(), sc.nextInt());
			//enter student2 details
			System.out.println("Enter Student 2nd Details : ID, Name, Email and Age.");
			Student detailS2 = new Student(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.next(), sc.nextInt());
            //fetch student1 && student2 details
			System.out.println("\n");
			System.out.println(detailS1.fetchDetails() + "\n");
			System.out.println(detailS2.fetchDetails() + "\n");
            //enter marks student1 and student2
			System.out.println("Enter marks for Students");
			System.out.println("Enter Quiz Marks,Test Marks,Assignment Marks out of 100 for 1st Student.");
			Student marks = new Student();
			double setgpa1 = marks.computeGPA(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
			detailS1.setGpa(setgpa1);
			System.out.println("Enter Quiz Marks,Test Marks,Assignment Marks out of 100 for 2nd Student.");
			double setgpa2 = marks.computeGPA(sc.nextDouble(), sc.nextDouble(), sc.nextDouble());
			detailS2.setGpa(setgpa2);
			System.out.println(detailS1.fetchDetails() + "\n");
			System.out.println(detailS2.fetchDetails() + "\n");
			if (setgpa1 > setgpa2)
				
				System.out.println("TOPPER IS:"+detailS1.getName());
			else
				System.out.println("TOPPER IS:"+detailS2.getName());

			sc.close();
		}

	}


