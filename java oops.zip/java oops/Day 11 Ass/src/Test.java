import static utils.ValidationRules.checkCustomerType;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

import com.app.data.Customer;

import custom_exceptions.MyException;

public class Test {

	public static void main(String[] args) throws ParseException, MyException {
//		Object e1=new Customer("anup@gmail.com", "asfaf", "Anupam", 2222, "afdsf");
//		Object e2=new Customer("anup@gmail.com", "assfsfaf", "Anupam", 2222, "afdsf");
//		System.out.println(e1.equals(e2));
		
//		Date d1 = new Date();
//		System.out.println(d1);
//		Date d2 = new Date(0);
////		System.out.println(d2);
//		Date d3 = Customer.sdf.parse("2020-01-01");
//		System.out.println(d3);
//		System.out.println("d1 before d2 " + d1.before(d3));
//		Scanner sc = new Scanner (System.in);
//		System.out.println("Enter Customer Type");
//		   String type = sc.next();
//		   checkCustomerType(type);
		String s1 = "hi";
		System.gc();
		String s2 = "hi";
		System.out.println(s1 + s2);
	}

}
