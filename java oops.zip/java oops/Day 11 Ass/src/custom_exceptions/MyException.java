package custom_exceptions;

@SuppressWarnings("serial")
public class MyException extends Exception {

	public MyException(String errorMessage) {
		super(errorMessage);
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	
	
}
