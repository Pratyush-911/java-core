package com.app.data;

public enum CustomerType {
	SILVER,GOLD,PLATINUM
}
