package com.app.data;

public class Customer
{
	private String email , name , city , password;
	private int registrationAmount ;
	
	public Customer(String name , String email , String city ,int registrationAmount,String password)
	{
		this.email=email;
		this.name=name;
		this.city=city;
		this.registrationAmount=registrationAmount;
		this.password=password;
	}
	public Customer(String email)
	{
		this.email=email;
	}
	@Override
	public String toString()
	{
		return "Customer name : "+name+" email: "+email+" city : "+city+" Registration amount : "+registrationAmount;
	}
	
	@Override
	public boolean equals(Object cust)
	{
		return cust instanceof Customer ?this.email.equals(((Customer)cust).email) : false ;
	}
	
	public String getCity()
	{
		return this.city;
	}
}
