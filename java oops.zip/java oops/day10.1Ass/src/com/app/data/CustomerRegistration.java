package com.app.data;

import java.util.*;
import static utils.ValidationRules.*;

public class CustomerRegistration {

	public static void main(String[] args)
	{
		try(Scanner sc=new Scanner(System.in))
		{
			Customer[] customer=new Customer[10];
			int count=0;
			boolean exit=false;
			while(!exit)
			{
				System.out.println("Options\n1)Register Customer \n2)Display details of all Customers \n3)Find Customer in particular city \n4)exit");
				System.out.println("Enter your choice");
				try 
				{
					switch(sc.nextInt())
					{
					case 1:System.out.println("Enter Customer's email");
						   String emailCust=sc.next();
						   checkEmail(emailCust);
						   duplicateEmail(customer,emailCust);
						   System.out.println("Enter Customer's name");
						   String nameCust=sc.next();
						   System.out.println("Enter password ");
						   String passwordCust=sc.next();
						   passCheck(passwordCust) ;
						   System.out.println("Enter registration amount");
						   int registrationAmountCust=sc.nextInt();
						   RegAmountCheck(registrationAmountCust);
						   System.out.println("Enter your city");
						   String cityCust=sc.next();
						   customer[count]=new Customer(nameCust , emailCust , cityCust ,registrationAmountCust,passwordCust);
						   count++;
						   break;
					case 2:
						for(Customer c:customer)
						{
							if(c!=null)
							System.out.println(c);
						}
						break;
					case 3:
						System.out.println("Enter the city to be searched for");
						String citySearch=sc.next();
							for(Customer c:customer)
							{
								if(c!=null)
								{
									if(c.getCity().equals(citySearch))
										System.out.println(c);
									else
										System.out.println("City not found!!");
								}
							}
							break;
					case 4:
						exit=true;
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

	}
}
