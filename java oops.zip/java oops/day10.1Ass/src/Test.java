import com.app.data.Customer;

public class Test {

	public static void main(String[] args) {
		Object e1=new Customer("anup@gmail.com", "asfaf", "Anupam", 2222, "afdsf");
		Object e2=new Customer("anup@gmail.com", "assfsfaf", "Anupam", 2222, "afdsf");
		System.out.println(e1.equals(e2));
	}

}
