package utils;

import com.app.data.Customer;

import custom_exceptions.MyException;

public class ValidationRules {
	public static void checkEmail(String email) throws MyException
	{
		if(email.length()<8 || email.length()>30)
			throw new MyException("Length of email should be greater than 8 and less than 15");
		
		if(!(email.contains("@")))
				throw new MyException("Email should contain @ symbol.");
		
		if(!(email.endsWith(".com")))
			throw new MyException("Email should end with .com ");
	}
	
	public static void passCheck(String password) throws MyException
	{
		if(!(password.matches("((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{6,20})")))
				throw new MyException("Password must be of length 6-20 char and should contain special chars and digits");
	}
	
	public static void RegAmountCheck(int registrationAmount) throws MyException
	{
		if(registrationAmount % 500 !=0)
			throw new MyException("Registration amount should be multiple of 500");
	}
	public static void duplicateEmail(Customer[] customer,String email) throws MyException
	{
		for(Customer c:customer)
		{
			if(c!=null && c.equals(new Customer(email)))
				throw new MyException("Duplicate email found");
		}
	}
}

