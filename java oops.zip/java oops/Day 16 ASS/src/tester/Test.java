package tester;
import java.util.*;

public class Test {

	public static void main(String[] args){
		String names[] = {"Rama","Kiran","Shubham","Kaustubh","Sameer","Riya","Anish","Rama","Riya","Priya","Anuja"};
		List<String> list = new ArrayList<String>();
		Collections.addAll(list, names);
		System.out.println("ArrayList");
		for (String s : list) {
			System.out.println(s.toString());  // ArrayList : allows duplicate & not sorted by default
		}
		
		System.out.println("\nHashSet");
		HashSet<String> hash = new HashSet<String>();
		Collections.addAll(hash, names);
		for (String s : hash) {
			System.out.println(s.toString());  // HashSet : no duplicates & not sorted by default
		}
		
		System.out.println("\nLinkedHashSet");
		LinkedHashSet<String> link = new LinkedHashSet<String>();
		Collections.addAll(link, names);
		for (String s : link) {
			System.out.println(s.toString());  // LinkedHashSet : no duplicates & not sorted by default
		}
		
		System.out.println("\nTreeSet");
		Set<String> tree = new TreeSet<String>();
		Collections.addAll(tree, names);
		for (String s : tree) {
			System.out.println(s.toString());  // TreeSet : no duplicates & sorted by default
		}
		
	}

}
