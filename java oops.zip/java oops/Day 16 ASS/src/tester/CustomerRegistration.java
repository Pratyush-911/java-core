package tester;

import java.util.*;

import com.app.data.Customer;

import custom_comparators.CustomerRegAmountComparator;

import static utils.CollectionUtils.*;

public class CustomerRegistration {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			ArrayList<Customer> customer = populateCustomers();
			boolean exit = false;
			while (!exit) {
				System.out.println(
						"Options\n1) Show all Customers \n2) Sort customers as per email & dob \n3) Sort customers as per registration amount \n4) Sort customers as per city & registration amount \n5) Sort customers as per customer type & state\n6) Exit");
				System.out.println("Enter your choice");
				try {
					switch (sc.nextInt()) {
					case 1:
						for (Customer c : customer) {
							System.out.println(c.toString());
						}
						break;
					case 2:
						Collections.sort(customer);
						break;
					case 3:
						Collections.sort(customer, new CustomerRegAmountComparator());
						break;
					case 4:
						Collections.sort(customer, new Comparator<Customer>() {

							@Override
							public int compare(Customer o1, Customer o2) {
								if (o1.getCity().compareTo(o2.getCity()) == 0) {
									if (o1.getRegistrationAmount() > o2.getRegistrationAmount())
										return 1;
									else if (o1.getRegistrationAmount() < o2.getRegistrationAmount())
										return -1;
									else
										return 0;}
								else return o1.getCity().compareTo(o2.getCity());
							}
						});
						break;
					case 5:
						Collections.sort(customer, new Comparator<Customer>() {

							@Override
							public int compare(Customer o1, Customer o2) {
								if (o1.getType().compareTo(o2.getType()) == 0) 
									return o1.getState().compareTo(o2.getState());
								else return o1.getType().compareTo(o2.getType());
							}
						});
						break;
					case 6:
						exit = true;
						break;
					default: System.out.println("Invalid option selected");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	

}
