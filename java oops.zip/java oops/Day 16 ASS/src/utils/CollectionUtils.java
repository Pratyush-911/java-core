package utils;

import java.text.ParseException;
import java.util.ArrayList;

import com.app.data.Customer;

public class CollectionUtils {
	
	public static ArrayList<Customer> populateCustomers() throws ParseException {
		ArrayList<Customer> cust = new ArrayList<Customer>();
		Customer c1 = new Customer("umesh", "umesh5@sdf.com", 23456, "password@123", Customer.sdf.parse("1995-12-12"), "gold");
		c1.setAddress("retrhyt", "asvbc", "India", "1234567890");
		cust.add(c1);
		c1 = new Customer("neelam", "umesh2@sdf.com", 150000, "password@123", Customer.sdf.parse("1996-12-12"), "dsfr");
		c1.setAddress("saf", "twref", "India", "1234567890");
		cust.add(c1);
		c1 = new Customer("sdbfb", "umesh3@sdf.com", 2000, "password@123", Customer.sdf.parse("1997-12-12"), "asdfg");
		c1.setAddress("fgh", "dfg", "India", "1234567890");
		cust.add(c1);
		c1 = new Customer("asfd", "umesh1@sdf.com", 1234, "password@123", Customer.sdf.parse("1995-12-12"), "zxcv");
		c1.setAddress("asrt", "jku", "India", "1234567890");
		cust.add(c1);
		c1 = new Customer("ttyuu", "umesh5@sdf.com", 56789, "password@123", Customer.sdf.parse("1994-12-12"), "poiuy");
		c1.setAddress("zcfxg", "tyuyuu", "India", "1234567890");
		cust.add(c1);
//		cust.add(new Customer("umesh2", "umesh2@sdf.com", 150000, "password@123", Customer.sdf.parse("1995-12-12"), "silver").setAddress("Pune", "Mah", "India", "1234567890"));
//		cust.add(new Customer("umesh3", "umesh3@sdf.com", 150000, "password@123", Customer.sdf.parse("1995-12-12"), "platinum").setAddress("Pune", "Mah", "India", "1234567890"));
//		cust.add(new Customer("umesh4", "umesh4@sdf.com", 150000, "password@123", Customer.sdf.parse("1995-12-12"), "gold").setAddress("Pune", "Mah", "India", "1234567890"));
//		cust.add(new Customer("umesh5", "umesh5@sdf.com", 150000, "password@123", Customer.sdf.parse("1995-12-12"), "silver").setAddress("Pune", "Mah", "India", "1234567890"));
		return cust;
	}

}
