package com.app.data;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Customer implements Comparable<Customer>{
	private String email , name , password;
	private int registrationAmount ;
	private Date dob;
	private String type;
	private Address address;
	
	public static SimpleDateFormat sdf;
	static {
		sdf=new SimpleDateFormat("yyyy-MM-dd");
	}
	
	public Customer(String name , String email  ,int registrationAmount,String password, Date dob, String type)
	{
		this.email=email;
		this.name=name;
		this.registrationAmount=registrationAmount;
		this.password=password;
		this.dob = dob;
		this.type= type.toUpperCase();
	}
	public Customer(String email)
	{
		this.email=email;
	}
	
	@Override
	public String toString()
	{
		return "Customer name : "+name+" email: "+email+ " Registration amount : "+registrationAmount + " Date of Birth : " + sdf.format(dob) + " Customer type : "+this.type + address.toString();
	}
	
	@Override
	public boolean equals(Object cust)
	{
		return cust instanceof Customer ?this.email.equals(((Customer)cust).email) : false ;
	}
	
	public Date getDob()
	{
		return this.dob;
	}
	
	public String getPassword()
	{
		return this.password;
	}
	
	public String getType()
	{
		return this.type;
	}
	
	public int getRegistrationAmount()
	{
		return this.registrationAmount;
	}
	
	@Override
	public int compareTo(Customer o) {
		if (this.email.compareTo(o.email) == 0)
			return this.dob.compareTo(o.dob);
		else return this.email.compareTo(o.email);
	}
	
	public String getCity()
	{
		return this.address.city;
	}
	
	public String getState()
	{
		return this.address.state;
	}
	
	public void setAddress(String city ,String state ,String country , String phoneNo) {
		address = new Address(city ,state ,country ,phoneNo);
	}
	
	private class Address{
		private String city ,state ,country , phoneNo;

		public Address(String city, String state, String country, String phoneNo) {
			super();
			this.city = city;
			this.state = state;
			this.country = country;
			this.phoneNo = phoneNo;
		}

		@Override
		public String toString() {
			return " Address [city=" + city + ", state=" + state + ", country=" + country + ", phoneNo=" + phoneNo + "]";
		}
		
	}
	
}
