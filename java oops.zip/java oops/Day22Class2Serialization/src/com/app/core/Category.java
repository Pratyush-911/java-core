package com.app.core;

public enum Category {
	GRAINS,FRUITS,OIL,BREAD
}
