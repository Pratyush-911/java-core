package com.app.core;
//Shipment Details : city,zipCode,phoneNo,shipmentDate

import java.io.Serializable;
import java.time.LocalDate;

@SuppressWarnings("serial")
public class ShipmentDetails implements Serializable {
	private String city,zipCode,phoneNo;
	private LocalDate shipmentDate;
	public ShipmentDetails(String city, String zipCode, String phoneNo, LocalDate shipmentDate) {
		super();
		this.city = city;
		this.zipCode = zipCode;
		this.phoneNo = phoneNo;
		this.shipmentDate = shipmentDate;
	}
	@Override
	public String toString() {
		return "ShipmentDetails [city=" + city + ", zipCode=" + zipCode + ", phoneNo=" + phoneNo + ", shipmentDate="
				+ shipmentDate + "]";
	}
	
}
