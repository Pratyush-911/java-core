package file_io;

import static utils.CollectionUtils.populateData;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.Scanner;

import com.app.core.Product;

public class Test1 {

	public static void main(String[] args) {
		System.out.println("Enter destination file path to save");
			try (Scanner sc=new Scanner(System.in);
				 PrintWriter pw=new PrintWriter(new FileWriter(sc.nextLine()))){
				populateData().stream().sorted(Comparator.comparing(Product::getManufactureDate)).forEach(pw::println);
//				HashMap<Integer, Product> map1=new HashMap<>();
//				map1.values().stream().sorted(Comparator.comparing(Product::getManufactureDate)).forEach(pw::println);
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

}
