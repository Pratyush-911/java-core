package file_io;

import java.util.Scanner;
import static utils.CollectionUtils.*;
import static utils.IOUtils.saveProdDetails;

public class SaveProdinfo {

	public static void main(String[] args) {
		//store map of products in a binary file, using serialization
		try(Scanner sc=new Scanner(System.in)) {
			System.out.println("Enter the file name to save product details.");
			saveProdDetails(populateMap(populateData()), sc.nextLine());
			System.out.println("Product details saved");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
