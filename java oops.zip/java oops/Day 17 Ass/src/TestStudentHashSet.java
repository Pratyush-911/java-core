import java.util.HashSet;
import static java.time.LocalDate.parse;

public class TestStudentHashSet {

	public static void main(String[] args) {
		//create empty HS
		HashSet<Student> students=new HashSet<>();
		students.add(new Student(100, "JAVA", "Anupam", 80, parse("2000-01-20")));
		students.add(new Student(101, "C++", "Anup", 80, parse("2010-10-15")));
		students.add(new Student(102, ".NET", "Umesh", 80, parse("2011-11-25")));
		students.add(new Student(103, "C", "Babita", 80, parse("1990-08-28")));
		students.add(new Student(104, "Spring", "Ashutosh", 80, parse("1995-02-11")));
		
		System.out.println("Size "+students.size());
		//attach for each to display
		for (Student student : students) {
			System.out.println(student);
			System.out.println("hashcode"+student.hashCode());
		}
	}

}