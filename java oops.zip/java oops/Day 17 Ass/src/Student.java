import java.time.LocalDate;

public class Student {
private int studentid;
private String courseName,name;
private int marks;
private LocalDate birthDate;
public Student(int studentid, String courseName, String name, int marks, LocalDate birthDate) {
	super();
	this.studentid = studentid;
	this.courseName = courseName;
	this.name = name;
	this.marks = marks;
	this.birthDate = birthDate;
}
@Override
public String toString() {
	return "Student [studentid=" + studentid + ", courseName=" + courseName + ", name=" + name + ", marks=" + marks
			+ ", birthDate=" + birthDate + "]";
}
@Override
public boolean equals(Object obj) {
	if(obj instanceof Student)
	{
		Student s=(Student) obj;
	return studentid==s.studentid;
	}
	return false;
}
@Override
public int hashCode() {
	
	//return 1000;
	return studentid;
}

}