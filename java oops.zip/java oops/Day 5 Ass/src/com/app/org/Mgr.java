package com.app.org;
public class Mgr extends Emp {
private double perfBonus;

public Mgr(int id,String name,int deptId,double basic,double perfBonus) {
	super(id,name,deptId,basic);
	this.perfBonus = perfBonus;
}
public String toString() {
	return super.toString()+""+perfBonus;
}
public double getString() {
	return super.getBasic()+perfBonus;
}

}
