package com.app.org;
public class Worker extends Emp {
private double hourWorked;
private double hourlyRate;
public Worker(int id, String name, int depId, double basic, double hourWorked, double hourlyRate) {
	super(id, name, depId, basic);
	this.hourWorked = hourWorked;
	this.hourlyRate = hourlyRate;
}

public String toString() {
	return super.toString()+""+hourlyRate+""+hourWorked;
}


}
