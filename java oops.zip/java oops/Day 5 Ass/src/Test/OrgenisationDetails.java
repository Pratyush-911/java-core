package Test;

import java.util.Scanner;

import com.app.org.Emp;
import com.app.org.Mgr;
import com.app.org.Worker;

public class OrgenisationDetails {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int count=0;
		System.out.println("Enter no of employees you wan to add.");
		Emp[] employee = new Emp[sc.nextInt()];
		boolean counter = true;
		while (counter) {
			System.out.println("Choose What You Want to do.");
			System.out.println("1.Hire Manager \n2.Hire Worker \n3.Show Details \n4.Exit");
			int key = sc.nextInt();
			switch (key) {
			case 1:
				if(count<employee.length)
				{
				System.out.println("Hire Manager");
				System.out.println("How Many managers u want to Hire");
				Mgr[] mgrArr1 = new Mgr[sc.nextInt()];
				for (int i = 0; i < mgrArr1.length; i++) {
					System.out.println("Enter Manager ID,Name,Dept_ID,Basic,Perf_Bonus of #" + i);
					employee[count++] = new Mgr(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.nextInt(), sc.nextDouble(),
							sc.nextDouble());
				}
				}else
					System.out.println("Manager Full");
				break;
			case 2:
				if(count<employee.length)
				{
				System.out.println("Hire Worker");
				System.out.println("How Many Workers u want to Hire");
				Worker[] wrkrArr1 = new Worker[sc.nextInt()];
				for (int i = 0; i < wrkrArr1.length; i++) {
					System.out.println("Enter Worker ID,Name,Dept_Id,Basic,Hours_Worked,Hourly_Rate");
					employee[count++] = new Worker(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.nextInt(), sc.nextDouble(),
							sc.nextDouble(), sc.nextDouble());
				}
				}else
					System.out.println("Worker Full");
				break;
			case 3:
				System.out.println("Employee Details");
				for (Emp emp : employee) {
					if (emp !=null)
					{
					System.out.println(emp.toString());
					System.out.println("Net Salary : "+emp.computeNetSal());
					}
					}
								
				break;
			case 4:
				counter = false;
				break;
			}
		}
	   sc.close();
	}

}