package Test;
import java.util.Scanner;

import com.app.org.Mgr;
import com.app.org.Worker;

public class Tester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean counter = true;
		while (counter) {
			System.out.println("Choose What You Want to do.");
			System.out.println("1.Hire Manager \n2.Hire Worker \n3.Show Details \n4.Exit");
			int key = sc.nextInt();
			switch (key) {
			case 1:
				System.out.println("Hire Manager");
				System.out.println("How Many managers u want to Hire");
				Mgr[] mgrArr = new Mgr[sc.nextInt()];
				for (int i = 0; i < mgrArr.length; i++) {
					System.out.println("Enter Manager ID,Name,Dept_ID,Basic,Perf_Bonus of #" + i);
					Mgr mgr1 = new Mgr(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.nextInt(), sc.nextDouble(),
							sc.nextDouble());
					System.out.println(mgr1.toString());
				}

				break;
			case 2:
				System.out.println("Hire Worker");
				System.out.println("How Many Workers u want to Hire");
				Worker[] wrkrArr = new Worker[sc.nextInt()];
				for (int i = 0; i < wrkrArr.length; i++) {
					System.out.println("Enter Worker ID,Name,Dept_Id,Basic,Hours_Worked,Hourly_Rate");
					Worker wrkr1 = new Worker(sc.nextInt(), sc.nextLine() + sc.nextLine(), sc.nextInt(), sc.nextDouble(),
							sc.nextDouble(), sc.nextDouble());
					System.out.println(wrkr1.toString());
				}

				break;
			case 3:System.out.println();
				break;
			case 4:
				counter = false;

			}
		}

		

		sc.close();
	}

}
